<!-- follow me template -->
<!-- <div class="made-with-love">
&copy;
  Разработал
  <i>♥</i>
  <a target="_blank" href="">Шипачев Матвей</a>
</div> -->

</body>
<script src="<?=JS?>bootstrap.bundle.min.js"></script>
<script src="<?=JS?>jquery-3.7.1.min.js"></script>
<script src="<?=JS?>jquery.maskedinput.min.js"></script>
<script src="<?=JS?>script.js"></script>
<script src="<?=JS?>styles.js"></script>
<script src="<?=JS?>timeline.js"></script>
<script src="<?=JS?>map.js"></script>

</html>