<?php

require('config.php');
require('functions/controller.php');
?>